/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inheritence;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */

/**
 * The Person class represents a person with a first name, last name, and ID.
 */
public class Person {
    private String firstName;
    private String lastName;
    private int id;
    
    /**
     * Constructs a Person object with the specified first name, last name, and ID.
     *
     * @param firstName the first name of the person
     * @param lastName  the last name of the person
     * @param id        the ID of the person
     */
public Person(String firstName, String lastName, int id) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
    }
    
    /**
     * Returns the first name of the person.
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Returns the last name of the person.
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Returns the ID of the person.
     * @return the ID
     */
    public int getId() {
        return id;
    }
    /**
     * Displays the details of the person
     */
    protected void display() {  //made it protected instead of private so s1.display can work. 
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("ID: " + id);
    }
    /**
     * main method that uses Person, Student, and Professor classes
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("*****Part A*****");
        
        Person p = new Person("Raya", "Whitaker", 800555555);
        p.display();
        
        System.out.println("*****Part B*****");
        
        Student s1 = new Student ("Xavier", "Cato", 900111222, "CS", 3.5, 75);
        s1.setTransfer(true);
        s1.setBalance(100);
        s1.addCourse("Java Programming");
        s1.addCourse("Calculus");
        
        s1.display();
        
        if (s1.dropCourse ("Spanish")) { 
            System.out.println("The class has been dropped");
        } else {
        System.out.println("You are not enrolled in this course. " + "No courses have been dropped.");
        }
        
        ArrayList<String> enrolledCourses = s1.getEnrolledCourses();
        
        System.out.println("You are enrolled in the following courses: "); 
        
        for (String course : enrolledCourses) { 
            System.out.println(course); 
        }
        
        System.out.println("*****Part C*****");
        
        Student s2 = new Student ("Kathrine", "Johnson", 900, "CS", 4.0, 100);
        Student s3 = new Student ("Roy", "Clay", 901, "Biology", 3.2, 85); 
        Student s4 = new Student ("Kimberly", "Bryant", 902, "EE", 3.0, 80);
        
        Professor prof1 = new Professor ("Mary", "Castro", 300, "CS", 80000.0);
        prof1.addAdvisee(s2); 
        prof1.addAdvisee(s3); 
        prof1.addAdvisee(s4);
        
        prof1.display();
        
        if (prof1.removeAdvisee(902)) {
            System.out.println("The advisee has been removed");
        } else {
            System.out.println("This student is not an advisee of Professor" + prof1.getFirstName() + " " + prof1.getLastName());
        }
        ArrayList<Student> myAdvisees = prof1.getAdvisees(); 
        System.out.println("Professor " + prof1.getFirstName() + " " + prof1.getLastName() + " advisees: ");
        
        for (Student s: myAdvisees) { 
            System.out.println(s.getFirstName() + " " + s.getLastName());
        }
    }
} 
