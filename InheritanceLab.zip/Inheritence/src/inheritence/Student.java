/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritence;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */
public class Student extends Person {
    private String major;
    private double gpa;
    private int credits;
    private double balance;
    private boolean transfer;
    private ArrayList<String> enrolledCourses;
    
    /**
    * Constructs a Student object with the specified major, first name, ID, GPA, and credits.
    *
    * @param firstName first name of the student
    * @param lastName   last name of the student
    * @param id         ID of the student
    * @param major      major of the student
    * @param gpa       GPA of the student
    * @param credits    number of credits the student has
    */
    public Student(String firstName,String lastName, int id, String major, double gpa, int credits) {
        super (firstName, lastName, id);
        this.major = major;
        this.gpa = gpa;
        this.credits = credits;
        this.balance = balance;
        balance = 0;
        enrolledCourses = new ArrayList<>();
    }
    /**
     * Returns the major of the student.
     * @return the major
    */
    public String getMajor() {
        return major;
    }
    /**
     * Returns the GPA of the student.
     * @return the GPA
    */
    public double getGPA() {
        return gpa;
    }
    /**
     * Returns the number of credits the student has
     * @return the number of credits
     */
    public int getCredits() {
        return credits;
    }
    /**
     * Returns boolean if student is transfer
     * @return the boolean transfer
     */
    public boolean isTransfer() {
        return transfer;
    }
    /**
     * Returns the double of balance the student has
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }
    /**
     * Returns the list of enrolled courses
     * @return the list of courses enrolled
     */
    public ArrayList<String> getEnrolledCourses() {
        return enrolledCourses;
    }
    /**
     * Sets the major of the student
     * @param major the major to set
    */
    public void setMajor(String major) {
        this.major = major;
    }
    /**
     * Sets the GPA of the student
     * @param gpa the GPA to set
     */
    public void setGPA(double gpa) {
        this.gpa = gpa;
    }
    /**
     * Sets the number of credits for the student
     * @param credits the number of credits to set
     */
    public void setCredits(int credits) {
        this.credits = credits;
    }
    /**
     * Sets whether the student is a transfer student or not
     * @param transfer true if the student is a transfer student, false other
     */
    public void setTransfer(boolean transfer) {
        this.transfer = transfer;
    }
    /**
     * Sets the balance of the student
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }
        /**
     * adds the course
     * @param course
     */
    public void addCourse(String course) {
        enrolledCourses.add(course);
    }
        /**
     * drops the set course
     * @param course
     * @return 
     */
    public boolean dropCourse(String course) {
        return enrolledCourses.remove(course);
    }

}
