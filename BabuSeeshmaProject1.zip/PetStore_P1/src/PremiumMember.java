
/**
 *
 * @author Seesh
 */

public class PremiumMember extends Member{
    
    private boolean duesPaid;

    /**
     * Constructs a PremiumMember object.
     *
     * @param name                  the name of the premium member
     * @param memberID              the ID of the premium member
     * @param newsletterSubscribed  whether the premium member is subscribed to the newsletter
     * @param duesPaid              whether the dues are paid by the premium member
     */
    public PremiumMember(String name, int memberID, boolean newsletterSubscribed, boolean duesPaid) {
        super(name, memberID, newsletterSubscribed);
        this.name = name;
        this.memberID = memberID;
        this.newsletterSubscribed = newsletterSubscribed;
        this.duesPaid = duesPaid;
    }

     /**
     * Checks if the dues are paid by the premium member.
     *
     * @return true if the dues are paid, false otherwise
     */
    public boolean isDuesPaid() {
        return duesPaid;
    }

    /**
     * Sets whether the dues are paid by the premium member.
     *
     * @param duesPaid true if the dues are paid, false otherwise
     */
    public void setDuesPaid(boolean duesPaid) {
        this.duesPaid = duesPaid;
    }
    
}
