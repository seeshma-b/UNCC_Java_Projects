/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */
public interface PetStoreSpecification {
    /**
     * update inventory by adding all the pets from ArrayList
     * @param pets ArrayList of pets that will be adopted
     */
    void startAdoptionDrive(ArrayList<Object> pets);
    
    /**
     * Calculate and return the amount in dollars for current inventory of pets that are in stock
     * @return amount in dollars of current inventory
     * 
     */
    double inventoryValue();
}
    
