/**
 *
 * @author Seesh
 */

import java.util. *;

public class PetStore implements PetStoreSpecification{

    private String storeName;
    private ArrayList<Pet> availablePets = new ArrayList<>();
    private ArrayList<Dog> availableDogs = new ArrayList();
    private ArrayList<Cat> availableCats = new ArrayList();
    private ArrayList<ExoticPet> availableExoticPets = new ArrayList();
    private ArrayList<Member> memberList = new ArrayList();
    private ArrayList<PremiumMember> premiumMemberList = new ArrayList();
    private static int nextPetID = 1;
    private static int nextMemberID = 1;

    public PetStore(String storeName) {
        this.storeName = storeName;
        Dog dog1 = new Dog("Waffle", "German Shepherd", "Female", 12, 101.1, getNextPetID(), 1, 250.0);
        Dog dog2 = new Dog("Poe", "Corgi", "Male", 3, 45.3, getNextPetID(), 1, 290.0);
        Cat cat1 = new Cat("Karma", "Orange Tabby", "Female", 5, 10.5, getNextPetID(), 1, 115.0);
        Cat cat2 = new Cat("Kit", "Maine Coon", "Male", 6, 24.2, getNextPetID(), 1, 350.0);
        ExoticPet ep1 = new ExoticPet("Pancake", "Bearded Dragon", "Male", 2, 1.0, getNextPetID(), 1, 60.0);
        ExoticPet ep2 = new ExoticPet("Noodle", "Ball Python", "Male", 4, 7.0, getNextPetID(), 1, 450.0);

        availableDogs.add(dog1);
        availableDogs.add(dog2);
        availableCats.add(cat1);
        availableCats.add(cat2);
        availableExoticPets.add(ep1);
        availableExoticPets.add(ep2);

        Member member1 = new Member("Jo", getNextMemberID(), true);
        member1.addCat(new Cat("Valjean", "White tabby", "Male", 3, 15.3, getNextPetID(), 1, 100.0));
        memberList.add(member1);

        PremiumMember member2 = new PremiumMember("Sage", getNextMemberID(), false, false);
        premiumMemberList.add(member2);
        member2.addExoticPet(new ExoticPet("Smaug", "Bearded Dragon", "Male", 3, 2.0, getNextPetID(), 1, 70.0));
    }

    @Override
    public void startAdoptionDrive(ArrayList<Object> pets) {
    for (Object pet : pets) {
        if (pet instanceof Pet) {
            Pet petObj = (Pet) pet;
            availablePets.add(petObj);
        }
    }
}
    
    @Override
    public double inventoryValue() {
        double value = 0.0;
        for (Pet pet : availablePets) {
            // Calculate the value of each pet and accumulate
            value += pet.getPrice();
        }
        return value;
    }
    
    public static int getNextPetID() { //increments pet ID
        nextPetID++;
        return nextPetID - 1;
    }
    
    public static int getNextMemberID() { // increments member ID
        nextMemberID++;
        return nextMemberID - 1;
    }

    public String getStoreName() { //getting the store name
        return storeName = "Babu's Pet Paradise";
    }

    public void setStoreName(String storeName) { //setting storename
        this.storeName = storeName;
    }
    
    public ArrayList<Pet> getAvailablePets() { //returns all avail pets
        return availablePets;
    }

    public void setAvailablePets(ArrayList<Pet> availablePets) {
        this.availablePets = availablePets;
    }

    public ArrayList<Dog> getAvailableDogs() {
        return availableDogs;
    }

    public void setAvailableDogs(ArrayList<Dog> availableDogs) {
        this.availableDogs = availableDogs;
    }

    public ArrayList<Cat> getAvailableCats() {
        return availableCats;
    }

    public void setAvailableCats(ArrayList<Cat> availableCats) {
        this.availableCats = availableCats;
    }

    public ArrayList<ExoticPet> getAvailableExoticPets() {
        return availableExoticPets;
    }

    public void setAvailableExoticPets(ArrayList<ExoticPet> availableExoticPets) {
        this.availableExoticPets = availableExoticPets;
    }

    public ArrayList<Member> getMemberList() {
        return memberList;
    }

    public void setMemberList(ArrayList<Member> memberList) {
        this.memberList = memberList;
    }

    public ArrayList<PremiumMember> getPremiumMemberList() {
        return premiumMemberList;
    }

    public void setPremiumMemberList(ArrayList<PremiumMember> premiumMemberList) {
        this.premiumMemberList = premiumMemberList;
    }

    public void removePet(String type, int index) { 
        if (type.equals("dog")) 
            availableDogs.remove(index);
        else if (type.equals("cat")) 
            availableCats.remove(index);
        else if (type.equals("exoticPet")) 
            availableExoticPets.remove(index);
    }

    public void addNewMember(String name, boolean premium) {
        if (premium) {
            premiumMemberList.add(new PremiumMember(name,getNextMemberID(),false,false));
        } else {
            memberList.add(new Member(name,getNextMemberID(), false));
        }
    }
}

    
     
