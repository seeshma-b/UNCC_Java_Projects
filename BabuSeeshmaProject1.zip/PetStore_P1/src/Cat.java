/**
 *
 * @author Seesh
 */

public class Cat extends Pet {
    
    private String breed;

    /**
     * Constructs a Cat object.
     *
     * @param name   the name of the cat
     * @param breed  the breed of the cat
     * @param sex    the sex of the cat
     * @param age    the age of the cat
     * @param weight the weight of the cat
     * @param ID     the ID of the cat
     * @param stock  the stock of the cat
     * @param price  the price of the cat
     */
    public Cat(String name, String breed, String sex, int age, double weight, int ID, int stock, double price) {
        super(name, sex, age, weight, ID, stock, price);
        this.breed = breed;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.ID = ID;
    }

    /**
     * Retrieves the breed of the cat
     *
     * @return the breed of the cat
     */
    public String getBreed() {
        return breed;
    }

     /**
     * Sets the breed of the cat
     *
     * @param breed the breed of the cat
     */
    public void setBreed(String breed) {
        this.breed = breed;
    }
}
