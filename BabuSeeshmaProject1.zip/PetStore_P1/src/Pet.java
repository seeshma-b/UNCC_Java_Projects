/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Seesh
 *
 * Abstract class representing a pet.
 */
abstract class Pet implements Comparable<Pet> {
    String name;
    String sex;
    int age;
    double weight;
    int ID;
    double price;
    int stock;
    
    /**
     * Constructor for the Pet class.
     *
     * @param name   the name of the pet
     * @param sex    the sex of the pet
     * @param age    the age of the pet
     * @param weight the weight of the pet
     * @param ID     the ID of the pet
     * @param stock  the stock of the pet
     * @param price  the price of the pet
     */
    public Pet(String name,String sex, int age, double weight, int ID,int stock, double price){
        this.name = name;
        this.price = price;
        this.stock = stock;             
    }
    
    /**
     * Retrieves the name of the pet.
     *
     * @return the name of the pet
     */
    public String getName() { //getters and setters for name, price and stock
        return this.name;
    }
   
    /**
     * Retrieves the sex of the pet.
     *
     * @return the sex of the pet
     */
    public String getSex() {
        return sex;
    }
    
    /**
     * Sets the sex of the pet.
     *
     * @param sex the sex of the pet
     */
    public void setSex(String sex) {
        this.sex = sex;
    }
    
    /**
     * Retrieves the age of the pet.
     *
     * @return the age of the pet
     */
    public int getAge() {
        return age;
    }
    
    /**
     * Sets the age of the pet.
     *
     * @param age the age of the pet
     */
    public void setAge(int age) {
        this.age = age;
    }
    
    /**
     * Retrieves the weight of the pet.
     *
     * @return the weight of the pet
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Sets the weight of the pet.
     *
     * @param weight the weight of the pet
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
        
    /**
     * Retrieves the ID of the pet.
     *
     * @return the ID of the pet
     */
    public int getID() {
        return ID;
    }

    /**
     * Sets the ID of the pet.
     *
     * @param ID the ID of the pet
     */
    public void setID(int ID) {
        this.ID = ID;
    }
    
    /**
     * Retrieves the price of the pet.
     *
     * @return the price of the pet
     */
    public double getPrice() {
        return this.price;
    }
    
    /**
     * Sets the price of the pet.
     *
     * @param price the price of the pet
     */
    public void setPrice(double price) {
        this.price = price;
    }
    
    /**
     * Retrieves the stock of the pet.
     *
     * @return the stock of the pet
     */
    public int getStock() {
        return stock;
    }
    
    /**
     * Sets the stock of the pet.
     *
     * @param stock the stock of the pet
     */
    public void setStock(int stock) {
        this.stock = stock;
    }
     
    /**
     * Compares this pet to another pet based on their prices
     *
     * @param other the other pet to compare to
     * @return -1 if this pet's price is less than the other pet's price,
     *         1 if this pet's price is greater than the other pet's price,
     *         0 if both pets have the same price
     */
    @Override
    public int compareTo(Pet other) {
        if (this.getPrice() < other.getPrice()) {
            return -1;
        } else if (this.getPrice() > other.getPrice()) {
            return 1;
        } else {
            return 0;
        }
    }

}
