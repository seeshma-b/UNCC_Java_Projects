import java.util. *;

/**
 *
 * @author Seesh
 */

public class Main {

    public static void main(String[] args) {

        Scanner scnr = new Scanner(System.in);
        PetStore ps = new PetStore("Babu's Pet Paradise");
        System.out.println("!#!#!#!#!#**** Welcome to " + ps.getStoreName() + "****#!#!#!#!#!"); //prints out store name and heading
        while (true) {

            //prints out the options for user to choose from
            System.out.println("\nPlease select from one of the following menu otions");
            System.out.println("\t1. Buy a new pet");
            System.out.println("\t2. Register a new member");
            System.out.println("\t3. Start adoption drive (add new pets)");
            System.out.println("\t4. Remove pet");
            System.out.println("\t5. Check current inventory");
            System.out.println("\t6. Check inventory value");
            System.out.println("\t7. Register new pet to Owner profile");
            System.out.println("\t8. Compare pet prices");
            System.out.println("\t9. Checkout?");
            System.out.println("\t10. Exit");

            int choice1 = scnr.nextInt();

            //case statements for each corresponding option for user
            switch (choice1) {
                case 1:
                    System.out.println("---------------------------------------------");
                    purchase(ps, scnr);
                    break;
                case 2:
                    System.out.println("---------------------------------------------");
                    registerNewMember(ps, scnr);
                    break;
                case 3:
                    System.out.println("---------------------------------------------");
                    startAdoptionDrive(ps, scnr);
                    break;
                case 4:
                    System.out.println("---------------------------------------------");
                    removePet(ps, scnr);
                    break;    
                case 5:
                    System.out.println("---------------------------------------------");
                    checkInventory(ps);
                    break;
                case 6:
                    System.out.println("---------------------------------------------");
                    inventoryValue(ps);
                    break;
                case 7:
                    System.out.println("---------------------------------------------");
                    registerPetToOwner(ps, scnr);
                    break;
                case 8:
                    System.out.println("---------------------------------------------");
                    compareTo(ps, scnr, ps.getAvailablePets());
                    break;    
                case 9:
                    System.out.println("---------------------------------------------");
                    checkout(ps, scnr, new ArrayList<>());
                    break;
                case 10:
                    System.out.println("---------------------------------------------");
                    System.out.println("Thanks for visiting!");
                    break;
                default:
                    System.out.println("---------------------------------------------");
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void purchase(PetStore petStore, Scanner scnr) { //the first option to choose from; user to pick what pet to purchase 
    System.out.println("What type of pet are you here to purchase?");
    System.out.println("\t1. Dogs");
    System.out.println("\t2. Cats");
    System.out.println("\t3. Exotic Pets");

    int petTypeChoice = scnr.nextInt();

    // display inventory menu
    switch (petTypeChoice) {
        case 1:
            ArrayList<Dog> availableDogs = petStore.getAvailableDogs();
            if (!availableDogs.isEmpty()) {
                System.out.println("Which dog would you like to purchase?");
                for (int i = 0; i < availableDogs.size(); i++) {
                    Dog dog = availableDogs.get(i);
                    System.out.println((i + 1) + ". " + dog.getName() + " - $" + dog.getPrice());
                    System.out.println("\tBreed: " + dog.getBreed());
                    System.out.println("\tSex: " + dog.getSex());
                    System.out.println("\tAge: " + dog.getAge());
                    System.out.println("\tWeight(lbs): " + dog.getWeight());
                    System.out.println("\tID: " + dog.getID());
                    System.out.println("\tStock: " + dog.getStock());
                }
                int dogChoice = scnr.nextInt();
                if (dogChoice >= 1 && dogChoice <= availableDogs.size()) {
                    Dog selectedDog = availableDogs.get(dogChoice - 1);
                    System.out.println("You have selected: " + selectedDog.getName());
                    // Perform purchase logic here
                    availableDogs.remove(dogChoice - 1);
                    System.out.println("Purchase successful!");
                } else {
                    System.out.println("Invalid choice.");
                }
            } else {
                System.out.println("No dogs available for purchase.");
            }
            break;
        case 2:
            ArrayList<Cat> availableCats = petStore.getAvailableCats();
            if (!availableCats.isEmpty()) {
                System.out.println("Which cat would you like to purchase?");
                for (int i = 0; i < availableCats.size(); i++) {
                    Cat cat = availableCats.get(i);
                    System.out.println((i + 1) + ". " + cat.getName() + " - $" + cat.getPrice());
                    System.out.println("\tBreed: " + cat.getBreed());
                    System.out.println("\tSex: " + cat.getSex());
                    System.out.println("\tAge: " + cat.getAge());
                    System.out.println("\tWeight(lbs): " + cat.getWeight());
                    System.out.println("\tID: " + cat.getID());
                    System.out.println("\tStock: " + cat.getStock());
                }
                int catChoice = scnr.nextInt();
                if (catChoice >= 1 && catChoice <= availableCats.size()) {
                    Cat selectedCat = availableCats.get(catChoice - 1);
                    System.out.println("You have selected: " + selectedCat.getName());
                    // Perform purchase logic here
                    availableCats.remove(catChoice - 1);
                    System.out.println("Purchase successful!");
                } else {
                    System.out.println("Invalid choice.");
                }
            } else {
                System.out.println("No cats available for purchase.");
            }
            break;
        case 3:
            ArrayList<ExoticPet> availableExoticPets = petStore.getAvailableExoticPets();
            if (!availableExoticPets.isEmpty()) {
                System.out.println("Which exotic pet would you like to purchase?");
                for (int i = 0; i < availableExoticPets.size(); i++) {
                    ExoticPet exoticPet = availableExoticPets.get(i);
                    System.out.println((i + 1) + ". " + exoticPet.getName() + " - $" + exoticPet.getPrice());
                    System.out.println("\tSpecies: " + exoticPet.getSpecies());
                    System.out.println("\tSex: " + exoticPet.getSex());
                    System.out.println("\tAge: " + exoticPet.getAge());
                    System.out.println("\tWeight(lbs): " + exoticPet.getWeight());
                    System.out.println("\tID: " + exoticPet.getID());
                    System.out.println("\tStock: " + exoticPet.getStock());
                }
                int exoticPetChoice = scnr.nextInt();
                if (exoticPetChoice >= 1 && exoticPetChoice <= availableExoticPets.size()) {
                    ExoticPet selectedExoticPet = availableExoticPets.get(exoticPetChoice - 1);
                    System.out.println("You have selected: " + selectedExoticPet.getName());
                    // Perform purchase logic here
                    availableExoticPets.remove(exoticPetChoice - 1);
                    System.out.println("Purchase successful!");
                } else {
                    System.out.println("Invalid choice.");
                }
            } else {
                System.out.println("No exotic pets available for purchase.");
            }
            break;
        default:
            System.out.println("Invalid choice.");
    }
}
    
    private static boolean registerNewMember(PetStore petStore, Scanner scnr) { //second option for user; is to register new member
    // Register a new member logic
    System.out.println("Enter member name:");
    String name = scnr.next();
    System.out.println("Is the member a premium member? (true/false)");
    boolean premium = scnr.nextBoolean();
    petStore.addNewMember(name, premium);
    System.out.println("New member registered successfully!");
    return premium;
}
        
    private static void startAdoptionDrive(PetStore petStore, Scanner scnr) { //thrid option for user; is to start adoption drive for pets
    System.out.println("Press Enter the number 1 to start!");
    int numInput = scnr.nextInt();

    for (int i = 0; i < numInput; i++) {
        System.out.println("Enter pet type to add into adoption drive - \t1) Dog \t2) Cat \t3) Exotic Pet: ");
        int petTypeChoice = scnr.nextInt();

        switch (petTypeChoice) {
            case 1:
                System.out.println("Enter dog details: ");
                // Read dog details from user (name, breed, gender, age, weight, stock, and price)
                System.out.println("Enter dog name: ");
                String dogName = scnr.next();
                System.out.println("Enter dog breed: ");
                String dogBreed = scnr.next();
                System.out.println("Enter dog gender (Male or Female): ");
                String dogGender = scnr.next();
                System.out.println("Enter dog age: ");
                int dogAge = scnr.nextInt();
                System.out.println("Enter dog weight(lbs): ");
                int dogWeight = scnr.nextInt();
                System.out.println("Enter how many dogs are in stock for this registration: ");
                int dogStock = scnr.nextInt();
                System.out.println("Enter dog price($): ");
                double dogPrice = scnr.nextDouble();

                // Create a new Dog object
                Dog dog = new Dog(dogName, dogBreed, dogGender, dogAge, dogWeight, petStore.getNextPetID(), dogStock, dogPrice);
                // Add the dog to the available dogs list in PetStore
                petStore.getAvailableDogs().add(dog);
                break;

            case 2:
                System.out.println("Enter cat details:");
                // Read cat details from user (name, breed, gender, age, weight, stock, and price)
                System.out.println("Enter cat name: ");
                String catName = scnr.next();
                System.out.println("Enter cat breed: ");
                String catBreed = scnr.next();
                System.out.println("Enter cat gender (Male or Female): ");
                String catGender = scnr.next();
                System.out.println("Enter cat age: ");
                int catAge = scnr.nextInt();
                System.out.println("Enter cat weight(lbs): ");
                int catWeight = scnr.nextInt();
                System.out.println("Enter how many cats are in stock for this registration: ");
                int catStock = scnr.nextInt();
                System.out.println("Enter cat price($): ");
                double catPrice = scnr.nextDouble();

                // Create a new Cat object
                Cat cat = new Cat(catName, catBreed, catGender, catAge, catWeight, petStore.getNextPetID(), catStock, catPrice);
                // Add the cat to the available cats list in PetStore
                petStore.getAvailableCats().add(cat);
                break;

            case 3:
                System.out.println("Enter exotic pet details:");
                // Read exotic pet details from user (name, species, gender, age, size, stock, and price)
                System.out.println("Enter exotic pet name: ");
                String exoticPetName = scnr.next();
                System.out.println("Enter exotic pet species: ");
                String exoticPetSpecies = scnr.next();
                System.out.println("Enter exotic pet gender (Male or Female: ");
                String exoticPetGender = scnr.next();
                System.out.println("Enter exotic pet age: ");
                int exoticPetAge = scnr.nextInt();
                System.out.println("Enter exotic pet weight(lbs): ");
                double exoticPetWeight = scnr.nextDouble();
                System.out.println("Enter how many exotic pets are in stock for this registration: ");
                int exoticPetStock = scnr.nextInt();
                System.out.println("Enter exotic pet price($): ");
                double exoticPetPrice = scnr.nextDouble();

                // Create a new ExoticPet object
                ExoticPet exoticPet = new ExoticPet(exoticPetName, exoticPetSpecies, exoticPetGender, exoticPetAge, exoticPetWeight, petStore.getNextPetID(), exoticPetStock, exoticPetPrice);
                // Add the exotic pet to the available exotic pets list in PetStore
                petStore.getAvailableExoticPets().add(exoticPet);
                break;

            default:
                System.out.println("Invalid pet type.");
                break;
        }
    }

    System.out.println("\tAdoption drive completed!");
}
        
    private static void removePet(PetStore petStore, Scanner scnr) { //fourth option for user to choose from; is to remove pet from the available animals
    System.out.println("Enter the type of pet to remove \t1.Dog \t2.Cat \t3.Exotic Pet ");
    int petType = scnr.nextInt();

    switch (petType) {
        case 1:
            System.out.println("Available Dogs:");
            ArrayList<Dog> dogs = petStore.getAvailableDogs();
            for (int i = 0; i < dogs.size(); i++) {
                Dog dog = dogs.get(i);
                System.out.println((i + 1) + ". " + dog.getName());
            }
            System.out.println("Enter the index of the dog to remove:");
            int dogIndex = scnr.nextInt();
            if (dogIndex >= 1 && dogIndex <= dogs.size()) {
                petStore.removePet("dog", dogIndex - 1);
                System.out.println("Dog removed successfully!");
            } else {
                System.out.println("Invalid index.");
            }
            break;
        case 2:
            System.out.println("Available Cats:");
            ArrayList<Cat> cats = petStore.getAvailableCats();
            for (int i = 0; i < cats.size(); i++) {
                Cat cat = cats.get(i);
                System.out.println((i + 1) + ". " + cat.getName());
            }
            System.out.println("Enter the index of the cat to remove:");
            int catIndex = scnr.nextInt();
            if (catIndex >= 1 && catIndex <= cats.size()) {
                petStore.removePet("cat", catIndex - 1);
                System.out.println("Cat removed successfully!");
            } else {
                System.out.println("Invalid index.");
            }
            break;
        case 3:
            System.out.println("Available Exotic Pets:");
            ArrayList<ExoticPet> exoticPets = petStore.getAvailableExoticPets();
            for (int i = 0; i < exoticPets.size(); i++) {
                ExoticPet exoticPet = exoticPets.get(i);
                System.out.println((i + 1) + ". " + exoticPet.getName());
            }
            System.out.println("Enter the index of the exotic pet to remove:");
            int exoticPetIndex = scnr.nextInt();
            if (exoticPetIndex >= 1 && exoticPetIndex <= exoticPets.size()) {
                petStore.removePet("exoticPet", exoticPetIndex - 1);
                System.out.println("Exotic pet removed successfully!");
            } else {
                System.out.println("Invalid index.");
            }
            break;
        default:
            System.out.println("Invalid pet type.");
    }
}
    
    private static void checkInventory(PetStore petStore) { //fifth option for user; outputs for the current inventory
        System.out.println("\nAvailable Dogs:");
    ArrayList<Dog> dogs = petStore.getAvailableDogs();
    for (Dog dog : dogs) {
        System.out.println("\tID: " + dog.getID() + ", Name: " + dog.getName() + ", Breed: " + dog.getBreed() + ", Sex: " + dog.getSex() + ", Age: " + dog.getAge() + ", Weight(lbs): " + dog.getWeight() + ", Stock: " + dog.getStock() + ", Price: $" + dog.getPrice());
    }

        System.out.println("\nAvailable Cats:");
    ArrayList<Cat> cats = petStore.getAvailableCats();
    for (Cat cat : cats) {
        System.out.println("\tID: " + cat.getID() + ", Name: " + cat.getName() + ", Breed: " + cat.getBreed() + ", Sex: " + cat.getSex() + ", Age: " + cat.getAge() + ", Weight(lbs): " + cat.getWeight() + ", Stock: " + cat.getStock() + ", Price: $" + cat.getPrice());
    }

        System.out.println("\nAvailable Exotic Pets:");
    ArrayList<ExoticPet> exoticPets = petStore.getAvailableExoticPets();
    for (ExoticPet exoticPet : exoticPets) {
        System.out.println("\tID: " + exoticPet.getID() + ", Name: " + exoticPet.getName() + ", Species: " + exoticPet.getSpecies() + ", Sex: " + exoticPet.getSex() + ", Age: " + exoticPet.getAge() + ", Weight(lbs): " + exoticPet.getWeight() + ", Stock: " + exoticPet.getStock() + ", Price: $" + exoticPet.getPrice());
    }       
}
    
    private static double inventoryValue(PetStore petStore) { //sixth option for user; outputs the total value of the current inventory in dollars
    double value = 0.0;
    ArrayList<Dog> dogs = petStore.getAvailableDogs(); //total dogs value
    for (Dog dog : dogs) {
        value += dog.getPrice() * dog.getStock();
    }
    ArrayList<Cat> cats = petStore.getAvailableCats(); //total cats value
    for (Cat cat : cats) {
        value += cat.getPrice() * cat.getStock();
    }
    ArrayList<ExoticPet> exoticPets = petStore.getAvailableExoticPets(); //total exotic pets value 
    for (ExoticPet exoticPet : exoticPets) {
        value += exoticPet.getPrice() * exoticPet.getStock();
    }
    System.out.println("Inventory Value: $" + value);
    return value;
}
    
    private static void registerPetToOwner(PetStore petStore, Scanner scnr) {
    System.out.println("Registering a new pet owner.");
    System.out.println("Enter the owner's name:");
    String ownerName = scnr.next();

    // Check if the owner is already registered
    Member owner = null;
    for (Member member : petStore.getMemberList()) {
        if (member.getName().equalsIgnoreCase(ownerName)) {
            owner = member;
            break;
        }
    }
    if (owner == null) {
        for (PremiumMember premiumMember : petStore.getPremiumMemberList()) {
            if (premiumMember.getName().equalsIgnoreCase(ownerName)) {
                owner = premiumMember;
                break;
            }
        }
    }
    // If the owner is found, proceed to register the pet
    if (owner != null) {
        System.out.println("Enter the type of pet to register:");
        System.out.println("\t1. Dog");
        System.out.println("\t2. Cat");
        System.out.println("\t3. Exotic Pet");
        int petTypeChoice = scnr.nextInt();

        switch (petTypeChoice) {
            case 1:
                // Register a dog to the owner
                ArrayList<Dog> availableDogs = petStore.getAvailableDogs();
                if (!availableDogs.isEmpty()) {
                    System.out.println("Which dog would you like to register?");
                    for (int i = 0; i < availableDogs.size(); i++) {
                        Dog dog = availableDogs.get(i);
                        System.out.println((i + 1) + ". " + dog.getName() + " - $" + dog.getPrice());
                        System.out.println("\tID: " + dog.getID());
                        System.out.println("\tStock: " + dog.getStock());
                    }
                    int dogChoice = scnr.nextInt();
                    if (dogChoice >= 1 && dogChoice <= availableDogs.size()) {
                        Dog selectedDog = availableDogs.remove(dogChoice - 1);
                        owner.addDog(selectedDog);
                        System.out.println("Dog registered to " + owner.getName() + " successfully!");
                    } else {
                        System.out.println("Invalid choice.");
                    }
                } else {
                    System.out.println("No dogs available to register.");
                }
                break;

            case 2:
                // Register a cat to the owner
                ArrayList<Cat> availableCats = petStore.getAvailableCats();
                if (!availableCats.isEmpty()) {
                    System.out.println("Which cat would you like to register?");
                    for (int i = 0; i < availableCats.size(); i++) {
                        Cat cat = availableCats.get(i);
                        System.out.println((i + 1) + ". " + cat.getName() + " - $" + cat.getPrice());
                        System.out.println("\tID: " + cat.getID());
                        System.out.println("\tStock: " + cat.getStock());
                    }
                    int catChoice = scnr.nextInt();
                    if (catChoice >= 1 && catChoice <= availableCats.size()) {
                        Cat selectedCat = availableCats.remove(catChoice - 1);
                        owner.addCat(selectedCat);
                        System.out.println("Cat registered to " + owner.getName() + " successfully!");
                    } else {
                        System.out.println("Invalid choice.");
                    }
                } else {
                    System.out.println("No cats available to register.");
                }
                break;

            case 3:
                // Register an exotic pet to the owner
                ArrayList<ExoticPet> availableExoticPets = petStore.getAvailableExoticPets();
                if (!availableExoticPets.isEmpty()) {
                    System.out.println("Which exotic pet would you like to register?");
                    for (int i = 0; i < availableExoticPets.size(); i++) {
                        ExoticPet exoticPet = availableExoticPets.get(i);
                        System.out.println((i + 1) + ". " + exoticPet.getName() + " - $" + exoticPet.getPrice());
                        System.out.println("\tID: " + exoticPet.getID());
                        System.out.println("\tStock: " + exoticPet.getStock());
                    }
                    int exoticPetChoice = scnr.nextInt();
                    if (exoticPetChoice >= 1 && exoticPetChoice <= availableExoticPets.size()) {
                        ExoticPet selectedExoticPet = availableExoticPets.remove(exoticPetChoice - 1);
                        owner.addExoticPet(selectedExoticPet);
                        System.out.println("Exotic pet registered to " + owner.getName() + " successfully!");
                    } else {
                        System.out.println("Invalid choice. Try again.");
                    }
                } else {
                    System.out.println("No exotic pets available to register.");
                }
                break;

            default:
                System.out.println("Invalid choice. Try again.");
        }
    } else {
        System.out.println("Owner not found. Please register the owner first before registering a pet to an owner.");
    }
}

    private static void compareTo(PetStore petStore, Scanner scnr, ArrayList<Pet> getAvailablePets) { //eighth option for user; for user to compare price between two pets
        System.out.println("Enter the name of the first pet: ");
        String pet1Name = scnr.next();
        System.out.println("Enter the name of the second pet: ");
        String pet2Name = scnr.next();

        Pet pet1 = null;
        Pet pet2 = null;

        // Find the first pet by name
        for (Pet pet : getAvailablePets) {
            if (pet.getName().equalsIgnoreCase(pet1Name)) {
                pet1 = pet;
                break;
            }
        }
        // Find the second pet by name
        for (Pet pet : getAvailablePets) {
            if (pet.getName().equalsIgnoreCase(pet2Name)) {
                pet2 = pet;
                break;
            }
        }
        if (pet1 != null && pet2 != null) {
            int result = Double.compare(pet1.getPrice(), pet2.getPrice());
             
            System.out.println("Comparing " + pet1.getName() + " and " + pet2.getName() + ":");
            if (result < 0) {
                System.out.println(pet1.getName() + " is cheaper than " + pet2.getName());
            } else if (result > 0) {
                System.out.println(pet1.getName() + " is more expensive than " + pet2.getName());
            } else {
                System.out.println(pet1.getName() + " and " + pet2.getName() + " have the same price");
            }
        } else {
            System.out.println("One or both pets could not be found. Please check the names and try again.");
        }
    }
    
    private static void checkout(PetStore petStore, Scanner scnr, ArrayList<Pet> cart) { //ninth option for user; user to checkout their cart for their purchases
        // Calculate total
        double total = 0;
        for (Pet pet : cart) {
            total += pet.getPrice();
        }
        System.out.println("Your total comes to " + total + ". Please select which member is making this purchase:");

        // List members and option to register
        int num = 1;
        for (Member member : petStore.getMemberList()) {
            System.out.println(num + ". " + member.getName());
            num++;
        }
        for (PremiumMember member : petStore.getPremiumMemberList()) {
            System.out.println(num + ". " + member.getName());
            num++;
        }
        System.out.println(num + ". Register a new Member.");

        System.out.println(""); // Space line
        int memberSelect = scnr.nextInt();
        Member purchaser = null;
        PremiumMember premiumPurchaser = null;

        if (memberSelect > petStore.getMemberList().size() + petStore.getPremiumMemberList().size() + 1) {
            // Invalid selection
            System.out.println("Invalid Selection");
            checkout(petStore, scnr, cart); // call if valid user input
        } else {
            // Valid selection
            if (memberSelect == (petStore.getMemberList().size() + petStore.getPremiumMemberList().size()) + 1) {
                // Adding a new member
                boolean premium = registerNewMember(petStore, scnr); //  registerNewMember returns a boolean indicating premium membership
                if (premium) {
                    premiumPurchaser = petStore.getPremiumMemberList().get(petStore.getPremiumMemberList().size() - 1);
                } else {
                    purchaser = petStore.getMemberList().get(petStore.getMemberList().size() - 1);
                }
            } else if (memberSelect <= petStore.getMemberList().size()) {
                purchaser = petStore.getMemberList().get(memberSelect - 1);
            } else {
                // Existing premium member
                premiumPurchaser = petStore.getPremiumMemberList().get(memberSelect - petStore.getMemberList().size() - 1);
            }

            // Check if premium member and fees are due
            if (purchaser == null && premiumPurchaser != null) {
                if (!premiumPurchaser.isDuesPaid()) {
                    System.out.println("Premium Membership dues unpaid, $5 will be added to purchase total to cover dues.");
                    total += 5;
                }
                premiumPurchaser.setDuesPaid(true);
                // Update amount of purchases for this member
                premiumPurchaser.setAmountSpent(total);
                // Done
                System.out.println("Your purchase total was: " + total);
                System.out.println("Congrats on your purchase, " + premiumPurchaser.getName());
            } else {
                // Update amount of purchases for this member
                purchaser.setAmountSpent(total);
                System.out.println("Your purchase total was: " + total);
                System.out.println("Congrats on your purchase, " + purchaser.getName());
            }
        }
    }

}