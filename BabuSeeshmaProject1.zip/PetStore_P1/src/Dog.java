/**
 *
 * @author Seesh
 */

public class Dog extends Pet { 
        
    private String breed;

    /**
     * Constructs a Dog object.
     *
     * @param name   the name of the dog
     * @param breed  the breed of the dog
     * @param sex    the sex of the dog
     * @param age    the age of the dog
     * @param weight the weight of the dog
     * @param ID     the ID of the dog
     * @param stock  the stock of the dog
     * @param price  the price of the dog
     */
    public Dog(String name, String breed, String sex, int age, double weight, int ID, int stock, double price) {
        super(name, sex, age, weight, ID, stock, price);
        this.breed = breed;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.ID = ID;
    }

    /**
     * Retrieves the breed of the dog.
     *
     * @return the breed of the dog
     */
    public String getBreed() {
        return breed;
    }

    /**
     * Sets the breed of the dog.
     *
     * @param breed the breed of the dog
     */
    public void setBreed(String breed) {
        this.breed = breed;
    }

  
}
