/**
 *
 * @author Seesh
 */

public class ExoticPet extends Pet {

    private String species;
    
    /**
     * Constructs an ExoticPet object.
     *
     * @param name    the name of the exotic pet
     * @param species the species of the exotic pet
     * @param sex     the sex of the exotic pet
     * @param age     the age of the exotic pet
     * @param weight  the weight of the exotic pet
     * @param ID      the ID of the exotic pet
     * @param stock   the stock of the exotic pet
     * @param price   the price of the exotic pet
     */
    public ExoticPet(String name, String species, String sex, int age, double weight, int ID, int stock, double price) {
        super(name, sex, age, weight, ID, stock, price);
        this.species = species;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.ID = ID;
    }

    /**
     * Retrieves the species of the exotic pet.
     *
     * @return the species of the exotic pet
     */
    public String getSpecies() {
        return species;
    }

    /**
     * Sets the species of the exotic pet.
     *
     * @param species the species of the exotic pet
     */
    public void setSpecies(String species) {
        this.species = species;
    }

}
