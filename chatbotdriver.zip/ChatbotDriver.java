import java.util.Scanner;

public class ChatbotDriver{
/**
 * Create a Magpie, give it user input, and print its replies.
 */
    public static void main(String[] args) {
        // for formatting output
        String startMessage = "****************************  START  *******************************\n";
        String endMessage = "\n****************************   END   *******************************\n";
        System.out.println(startMessage);

        // create an instance of the Chatbot
        Chatbot maggie = new Chatbot();
        // print the Chatbot's welcome message
        System.out.println(maggie.getGreeting());
        // create a Scanner instance for user input
        Scanner in = new Scanner(System.in);
        // read the user input
        String statement = in.nextLine();

        // set the chatbot to respond to user input 
        // as long as the user does not input the word bye
        while (!statement.equalsIgnoreCase("Bye")) {
            //get a random response from the chatbot
            System.out.println(maggie.getResponse(statement));
            // read the user input
            statement = in.nextLine();
        }
        
        // the user entered bye print closing messages
        System.out.println("Goodbye!");
        System.out.println(endMessage);

    }
}

