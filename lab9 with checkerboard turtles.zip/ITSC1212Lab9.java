public class ITSC1212Lab9{

    public static void main(String[] args){
        // add code here
        char symbol = '%';
    
        for(int row = 0; row < 4; row++) {
            if(symbol == '%'){
                    symbol = '#';
                } else{ 
                    symbol = '%';                    
                }

            for(int col = 0; col < 4; col++) {
                if(symbol == '%') {
                    symbol = '#';
                    } else {
                    symbol = '%';
                    }
    
                System.out.print(" ");
                for(int x = 0; x < 4; x++) {
                {
                    System.out.print(symbol);
                }
                }
            }
                System.out.println(" ");
        }// end main method
    }//end class
}