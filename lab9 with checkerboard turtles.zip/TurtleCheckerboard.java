public class TurtleCheckerboard {
    
    public static void main(String[] args) {
        //create a world that is 500x500
        World w = new World(500,500);
        //create a turtle inside that world
        Turtle tom = new Turtle(w);
        //left pen
        tom.penUp();
        //place turtle at x=50, y=50
        tom.moveTo(50,50);
        //set heading to north
        tom.setHeading(0);
        //ready to draw, place pen down
        tom.penDown();

        // add code below this line
        for(int row = 0; row < 4; row++) {
            for(int square = 0; square < 4; square++) {
                tom.penUp();
                tom.moveTo(50 + (square * 100) , 50 + (row * 100));
                tom.penDown();
                tom.drawSquare();
            }
        }

    } // end main
} // end class