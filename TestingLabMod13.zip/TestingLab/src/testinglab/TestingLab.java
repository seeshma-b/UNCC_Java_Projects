/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testinglab;

/**
 *
 * @author Seesh
 */
public class TestingLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        StringAnalyzer wa = new StringAnalyzer();

        System.out.println("Testing firstRepeatedCharacter method");
        String s = "aardvark";
        char result = wa.firstRepeatedCharacter(s);
        System.out.println("Test 1 firstRepeatedCharacter: " + validate('a', result));

        s = "roommate";
        result = wa.firstRepeatedCharacter(s);
        System.out.println("Test 2 firstRepeatedCharacter: " + validate('o', result));

        s = "mate";
        result = wa.firstRepeatedCharacter(s);
        System.out.println("Test 3 firstRepeatedCharacter: " + validate('0', result));
        
        System.out.println("\n-----------------------------");
        System.out.println("\nTesting firstMultipleCharacter method");
        s = "abcdefg";
        result = wa.firstMultipleCharacter(s);
        System.out.println("Test 1 firstMultipleCharacter: " + validate('0', result));

        s = "hhhhhhello";
        result = wa.firstMultipleCharacter(s);
        System.out.println("Test 2 firstMultipleCharacter: " + validate('h', result));

        s = "crazzzzzzzzzzzzzy";
        result = wa.firstMultipleCharacter(s);
        System.out.println("Test 3 firstMultipleCharacter: " + validate('z', result));

        s = "yzxyzxyy";
        result = wa.firstMultipleCharacter(s);
        System.out.println("Test 4 firstMultipleCharacter: " + validate('y', result));
        
        System.out.println("\n-----------------------------");
        System.out.println("\nTesting countRepeatedCharacters method");
        s = "mississippiii";
        int intResult = wa.countRepeatedCharacters(s);
        System.out.println("Test 1 countRepeatedCharacters: " + validate(4, intResult));
        
        s = "test";
        intResult = wa.countRepeatedCharacters(s);
        System.out.println("Test 2 countRepeatedCharacters: " + validate(0, intResult));
        
        s = "aabbcdaaaabbb";
        intResult = wa.countRepeatedCharacters(s);
        System.out.println("Test 3 countRepeatedCharacters: " + validate(4, intResult));
        
        System.out.println("\n-----------------------------");
    }
    
    private static String validate(char expected, char result) {
        if (result != expected) {
            return ("The result " + result + " does not match expected: " + expected + " --->> Failed");
        } else {
            return ("The result " + result + " match expected: " + expected + "--->> OK");
        }
    }
    
  
    private static String validate(int expected, int result) {
        if (result != expected) {
            return ("The result " + result + " does not match expected: " + expected + " --->> Failed");
        } else {
            return ("The result " + result + " match expected: " + expected + "--->> OK");
        }
        
    }
}
