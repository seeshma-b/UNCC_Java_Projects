package votecounterproject;

/**
 * @version Spring 2019
 * @author clatulip
 */
public class VoteCounterProject {

    public static void main(String[] args) {
        //ArrayVoteCounter.runRandomElectionResults();
        
        ArrayListVoteCounter.runRandomElectionResults();
    }

}