/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package notebookdriver;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 * worked on this lab with my pals
 */
public class Note {
    private int id;
    private String category;
    private String title;
    private String body;
    private String date;
    
    public Note() {
    }
    public Note(int id, String category, String title, String body, String date) {
        this.id = 0;
        this.category = category;
        this.title = title;
        this.body = body;
        this.date = date;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getBody() {
        return body;
    }
    public void setBody(String body) {
        this.body = body;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    
}
