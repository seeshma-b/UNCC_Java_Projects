/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package notebookdriver;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 * also worked on this as a group with my pals
 */
public class Notebook {
    private String subject;
    private String owner;
    private ArrayList<Note> notes = new ArrayList<>(); //** initializing the array to a private constructor
    private static int nextNoteId;
    
    public Notebook() {
        
    }
    public Notebook(String subject, String owner) {
        this.subject = subject;
        this.owner = owner;
        this.notes = new ArrayList<>();
        updateNextNoteId();
    }
    public Notebook(String subject, String owner, ArrayList<Note> notes) {
        this.subject = subject;
        this.owner = owner;
        this.notes = notes;
    }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    public String getOwner() {
        return owner;
    }
    public void setOwner(String owner) {
        this.owner = owner;
    }
    public ArrayList<Note> getNotes() {
        return notes;
    }
     public void setNotes(ArrayList<Note> notes) {
        this.notes = notes;
        Notebook.updateNextNoteId();
    }
     public void addNote(Note i) {
        notes.add(i);
    }
    public boolean deleteNote(Note note) {
        if (notes.contains(note)){
            notes.remove(note);
            return true;
        }
        return false;
    }
    public void updateNote(Note updatedNote, String setTitle, String setCategory, String setBody, String setDate) { 
        if (notes.contains(updatedNote)) {
        int index = notes.indexOf(updatedNote);
        Note existingNote = notes.get(index);
        
        String newTitle = setTitle;
        if (!newTitle.isEmpty()) {
            existingNote.setTitle(newTitle);
        }
        String newCategory = setCategory;
        if (!newCategory.isEmpty()) {
            existingNote.setCategory(newCategory);
        }
        String newBody = setBody;
        if (!newBody.isEmpty()) {
            existingNote.setBody(newBody);
        }
        String newDate = setDate;
        if (!newDate.isEmpty()) {
            existingNote.setDate(newDate);
        }
        notes.set(index, existingNote);
        }
        //add code contains, index, 
        //check if note is present in ArrayList
        //check using conatins
        //figure out index where note is present
        //ask to update *title, category, body, date
        //if statement for  each, note.set"*" 
        //ask for new values *
        //call setter
        //final update
    }
    private static void updateNextNoteId() { 
        nextNoteId++;
    }
    public int getNextNoteId() {
        return nextNoteId;
    }
}
