/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package notebookdriver;
import java.util.*;
/**
 *
 * @author Seesh
 * 
 */
public class NotebookDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Notebook myNotebook = new Notebook();
        Note myNote = new Note();
        myNote.setCategory("ITS1213");
        myNote.setTitle("UML diagrams");
        myNote.setBody("A UML class diagram consists of one or more classes,"
                + " each with sections for the class name, attributes (data), "
                + "and operations (methods)");
        myNote.setDate("2/8/2022");
        myNotebook.addNote(myNote);
        
        for(Note aNote:myNotebook.getNotes()){
            System.out.println("Note title "+ aNote.getTitle());
        }
                
    }
}