import java.util.Scanner;

public class CandleShop {

    public static void main(String[] args) {

        System.out.println("*******************************");
        System.out.println("Project 3");
        System.out.println("*******************************");
        // Add code here
        Scanner sc = new Scanner(System.in);
        System.out.print("Type 1 name: "); //Candle 1 type
        String name1 = sc.nextLine();

        System.out.print("Type 1 price: ");
        double price1 = sc.nextDouble();

        System.out.print("Type 1 burn time: ");
        int burnTime1 = sc.nextInt();
        System.out.println("--------------------------------");

        sc.nextLine();
        System.out.print("Type 2 name: "); //Candle 2 type
        String name2 = sc.nextLine();

        System.out.print("Type 2 price: ");
        double price2 = sc.nextDouble();

        System.out.print("Type 2 burn time: ");
        int burnTime2 = sc.nextInt();
        System.out.println("--------------------------------");
        
        sc.nextLine();
        System.out.print("Type 3 name: "); //Candle 3 type
        String name3 = sc.nextLine();

        System.out.print("Type 3 price: ");
        double price3 = sc.nextDouble();

        System.out.print("Type 3 burn time: ");
        int burnTime3 = sc.nextInt();
        System.out.println("*******************************");
        
        sc.nextLine();
        Candle candle1 = new Candle(name1, 1, price1, burnTime1);
        Candle candle2 = new Candle(name2, 2, price2, burnTime2);
        Candle candle3 = new Candle(name3, 3, price3, burnTime3);

        System.out.println("Enter the number of candles of each type the customer wants to buy.");

        System.out.print("Type 1 quantity: ");
        int quantity1 = sc.nextInt();
        System.out.print("Type 2 quantity: ");
        int quantity2 = sc.nextInt();
        System.out.print("Type 3 quantity: ");
        int quantity3 = sc.nextInt();

        System.out.println("*******************************");
        System.out.println("Type 1 candle total cost: $" + (quantity1 * candle1.getCost()));
        System.out.println("Type 2 candle total cost: $" + (quantity2 * candle2.getCost()));
        System.out.println("Type 3 candle total cost: $" + (quantity3 * candle3.getCost()));
        System.out.println("*******************************");

        double totalPrice = candle1.getCost() * quantity1 + candle2.getCost() * quantity2 + candle3.getCost() * quantity3;
        double discount = 0.0; //create the loop for discounts

        if (totalPrice > 100.0) {
            discount = 0.2 * totalPrice;
        } else if (totalPrice > 55.0) {
            discount = 0.1 * totalPrice;
        } else if (totalPrice > 35.0) {
            discount = 0.07 * totalPrice;
        } else if (totalPrice > 20.0) {
            discount = 0.05 * totalPrice;
        }
        double finalPrice = totalPrice - discount;

        int totalBurnTime = 0; //use array for burntimes
        totalBurnTime += candle1.getTime();
        totalBurnTime += candle2.getTime();
        totalBurnTime += candle3.getTime();

        double costPerMinute = finalPrice / totalBurnTime;

        System.out.println("Total base price: $" + totalPrice);
        System.out.println("Discount total: $" + discount);
        System.out.println("Final price: $" + finalPrice);
        System.out.println("Total burn time of candles: " + totalBurnTime + " minutes");
        System.out.println("Total cost-per-minute is: $" + costPerMinute);
        System.out.println("*******************************");

        System.out.println("---Histogram of number of purchases!---");

        System.out.print(quantity1 + " type 1 (" + candle1.getName() + ") candles:");
        for (int i = 0; i < quantity1; i++) {
        System.out.print("@ ");
        }
        System.out.print("\n" + quantity2 + " type 2 (" + candle2.getName() + ") candles:");
        for (int i = 0; i < quantity2; i++) {
        System.out.print("% ");
        }
        System.out.print("\n" + quantity3 + " type 3 (" + candle3.getName() + ") candles:");
        for (int i = 0; i < quantity3; i++) {
        System.out.print("# ");
        }          

    }//end main
}// end class
