/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arraylist;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */
public class FastFoodKitchen {
    private static int nextOrderNum = 1;
    private final ArrayList<Order> orderList = new ArrayList<>();

    /**
     * Retrieves the next available order number.
     *
     * @return The next available order number.
     */
    public static int getNextOrderNum() {
        return nextOrderNum;
    }
    /**
     * Increments the next order number.
     */
    private static void incrementNextOrderNum() {
        nextOrderNum++;
    }
    /**
     * Adds a new order to the order list.
     *
     * @param ham    The number of hamburgers in the order.
     * @param cheese The number of cheeseburgers in the order.
     * @param veggie The number of veggieburgers in the order.
     * @param sodas  The number of sodas in the order.
     * @param toGo   Indicates if the order is for takeout (true) or dine-in (false).
     * @return The order number of the newly created order.
     */
    public int addOrder(int ham, int cheese, int veggie, int sodas, boolean toGo) {
        Order newOrder = new Order(ham, cheese, veggie, sodas, toGo, getNextOrderNum());
        orderList.add(newOrder);
        incrementNextOrderNum();
        return newOrder.getOrderNum();
    }

    /**
     * Cancels the last order in the order list.
     *
     * @return true if an order was canceled, false if the list is empty.
     */
    public boolean cancelLastOrder() {  //case2
        if (!orderList.isEmpty()) {
            orderList.remove(orderList.size() - 1);
            decrementNextOrderNum();
            return true;
        }
        return false;
    }
    /**
     * Retrieves the number of orders currently pending
     *
     * @return The number of orders pending.
     */
    public int getNumOrdersPending() {  //case 3
        return orderList.size();
    }
    /**
     * @return true or false if order is pending or completed
     */
    public boolean isOrderDone(int orderID) { //case 4
        for (Order order : orderList) {
            if (order.getOrderNum() == orderID) {
                return false;
            }
        }
        return true;
    }
    public boolean cancelOrder(int orderID) { //case 5
        for (Order order : orderList) {
            if (order.getOrderNum() == orderID) {
                orderList.remove(order);
                return true;
            }
        }
        return false;
    }
    private static void decrementNextOrderNum() {
        nextOrderNum--;
    }
    public int findOrderSeq(int orderID) { //ArrayList Part2 PartA     //case 6
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                return i;
            }
        }
        return -1;
    }
    public void insertionSort() { //case 7
        for (int j = 1; j < orderList.size(); j++) {
            Order temp = orderList.get(j);
            int possibleIndex = j;

            int tempTotalBurgers = temp.getTotalBurgers();
            int currTotalBurgers = orderList.get(possibleIndex - 1).getTotalBurgers();

            while (possibleIndex > 0 && tempTotalBurgers < currTotalBurgers) {
                orderList.set( possibleIndex, orderList.get(possibleIndex - 1 ) );
                possibleIndex--;
            }
            orderList.set(possibleIndex, temp);
        }
    }
    public ArrayList<Order> getOrderList() {
        return orderList;
    }
    
    public void selectionSort(){ //case 8
        for (int j= 0; j < orderList.size(); j++){
            int position = j;
            for (int k = j; k < orderList.size(); k++){
                if( orderList.get(k).getTotalBurgers() < orderList.get(position).getTotalBurgers() )
                position = k;
            }
            Order temp = orderList.get(position);
            orderList.set(position, orderList.get(j));
            orderList.set(j, temp);
        }
    }
    
    public int findOrderBin(int orderID){ //case9
        int left = 0;
        int right = orderList.size()-1;
        while (left <= right){
            int middle = left+(right-left)/2;
            int current = orderList.get(middle).getOrderNum();
            if (current == orderID) {
                return middle;
            }
            if (current < orderID){
                left = middle+1;
            }else{
                right = middle-1;
            }
        }
        return -1;
    }


    public FastFoodKitchen() {
        Order order1 = new Order(3, 5, 4, 10, true, getNextOrderNum());
        orderList.add(order1);
        incrementNextOrderNum();

        Order order2 = new Order(0, 0, 3, 3, false, getNextOrderNum());
        orderList.add(order2);
        incrementNextOrderNum();

        Order order3 = new Order(1, 1, 0, 2, false, getNextOrderNum());
        orderList.add(order3);
        incrementNextOrderNum();
    }
}
