/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arraylist;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */
public class FastFoodKitchen {
    private static int nextOrderNum = 1;
    private final ArrayList<Order> orderList = new ArrayList<>();

    /**
     * Retrieves the next available order number.
     *
     * @return The next available order number.
     */
    public static int getNextOrderNum() {
        return nextOrderNum;
    }
    /**
     * Increments the next order number.
     */
    private static void incrementNextOrderNum() {
        nextOrderNum++;
    }
    /**
     * Adds a new order to the order list.
     *
     * @param ham    The number of hamburgers in the order.
     * @param cheese The number of cheeseburgers in the order.
     * @param veggie The number of veggieburgers in the order.
     * @param sodas  The number of sodas in the order.
     * @param toGo   Indicates if the order is for takeout (true) or dine-in (false).
     * @return The order number of the newly created order.
     */
    public int addOrder(int ham, int cheese, int veggie, int sodas, boolean toGo) {
        Order newOrder = new Order(ham, cheese, veggie, sodas, toGo, getNextOrderNum());
        orderList.add(newOrder);
        incrementNextOrderNum();
        return newOrder.getOrderNum();
    }

    /**
     * Cancels the last order in the order list.
     *
     * @return true if an order was canceled, false if the list is empty.
     */
    public boolean cancelLastOrder() {
        if (!orderList.isEmpty()) {
            orderList.remove(orderList.size() - 1);
            decrementNextOrderNum();
            return true;
        }
        return false;
    }
    /**
     * Retrieves the number of orders currently pending.
     *
     * @return The number of orders pending.
     */
    public int getNumOrdersPending() {
        return orderList.size();
    }
    /**
     * Decrements the next order number.
     */
    public boolean isOrderDone(int orderID) {
        for (Order order : orderList) {
            if (order.getOrderNum() == orderID) {
                return false;
            }
        }
        return true;
    }
    public boolean cancelOrder(int orderID) {
        for (Order order : orderList) {
            if (order.getOrderNum() == orderID) {
                orderList.remove(order);
                return true;
            }
        }
        return false;
    }
    private static void decrementNextOrderNum() {
        nextOrderNum--;
    }
    public FastFoodKitchen() {
        Order order1 = new Order(3, 5, 4, 10, true, getNextOrderNum());
        orderList.add(order1);
        incrementNextOrderNum();

        Order order2 = new Order(0, 0, 3, 3, false, getNextOrderNum());
        orderList.add(order2);
        incrementNextOrderNum();

        Order order3 = new Order(1, 1, 0, 2, false, getNextOrderNum());
        orderList.add(order3);
        incrementNextOrderNum();
    }
}
