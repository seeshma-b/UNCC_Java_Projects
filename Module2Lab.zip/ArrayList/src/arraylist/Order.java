/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arraylist;

/**
 *
 * @author Seesh
 */

public class Order {
    private int numHamburgers = 0;
    private int numCheeseBurgers = 0;
    private int numVeggieBurgers = 0;
    private int numSodas = 0;
    private boolean orderToGo = false;
    private int orderNum;
    
    public int getNumHamburgers() {
        return numHamburgers;
    }
    public void setNumHamburgers(int value) {
        if (value < 0) {
            System.out.println("Error. Cannot be less than zero.");
        } else {
            numHamburgers = value;
        }
    }
    public int getNumCheeseBurgers() {
        return numCheeseBurgers;
    }
    public void setNumCheeseBurgers(int value) {
        if (value < 0) {
            System.out.println("Error. Cannot be less than zero.");
        } else {
            numCheeseBurgers = value;
        }
    }
    public int getNumVeggieBurgers() {
        return numVeggieBurgers;
    }
    public void setNumVeggieBurgers(int value) {
        if (value < 0) {
            System.out.println("Error. Cannot be less than zero.");
        } else {
            numVeggieBurgers = value;
        }
    }
    public int getNumSodas() {
        return numSodas;
    }
    public void setNumSodas(int value) {
        if (value < 0) {
            System.out.println("Error. Cannot be less than zero.");
        } else {
            numSodas = value;
        }
    }
    public boolean isOrderToGo() {
        return orderToGo;
    }
    public void setOrderToGo(boolean value) {
        orderToGo = value;
    }
    public int getOrderNum() {
        return orderNum;
    }
    public Order(int numHamburgers, int numCheeseBurgers, int numVeggieBurgers, int numSodas, boolean orderToGo, int orderNum) {
        this.numHamburgers = numHamburgers;
        this.numCheeseBurgers = numCheeseBurgers;
        this.numVeggieBurgers = numVeggieBurgers;
        this.numSodas = numSodas;
        this.orderToGo = orderToGo;
        this.orderNum = orderNum;
    }
}





