/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritence;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */
public class Professor extends Person {
    private String department;
    private double salary;
    private ArrayList<Student> advisees;

    /**
     * Constructs a Professor object with the specified first name, last name, ID, department, and salary
     * @param firstName  first name of the professor
     * @param lastName    last name of the professor
     * @param id          ID of the professor
     * @param department department of the professor
     * @param salary      salary of the professor
     */
    public Professor (String firstName, String lastName, int id, String department, double salary) {
        super (firstName, lastName, id);
        this.department = department;
        this.salary = salary;
        this.advisees = new ArrayList<>();
    }
    
    /**
     * Returns the department of the professor
     * @return the department
     */
    public String getDepartment() {
        return department;
    }
    /**
     * Returns the salary of the professor
     * @return the salary
     */
    public double getSalary() {
        return salary;
    }
    /**
     * Returns the list of advisees of the professor
     * @return the list of advisees
     */
    public ArrayList<Student> getAdvisees() {
        return advisees;
    }
    
    /**
     * Sets the department of the professor
     * @param department the department to set
     */
    public void setDepartment(String department) {
        this.department = department;
    }
    /**
     * Sets the salary of the professor
     * @param salary the salary to set
     */
    public void setSalary(double salary) {
        this.salary = salary;
    }
    /**
     * Adds a student as an advisee of the professor
     * @param student the student to add as an advisee
     */
    public void addAdvisee(Student student) {
        advisees.add(student);
    }
    
    /**
     * Removes an advisee with the specified ID from the list of advisees
     * @param id the ID of the advisee to remove
     * @return true if the advisee was removed, false other
     */
    public boolean removeAdvisee(int id) {
        for (Student student : advisees) {
            if (student.getId() == id) {
                advisees.remove(student);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void display () { //mod 7 part B
        super.display();
        System.out.println("Department: " + department + "\tSalary: " + salary);
        System.out.println("Advisees: ");
        
        for (Student s : advisees) {
            System.out.println("\t" + s.getFirstName() + " " + s.getLastName());
        }
    }
    
    @Override
    public String toString() {
        return "Professor - " + this.getFirstName() + " " + this.getLastName();
    }
}
