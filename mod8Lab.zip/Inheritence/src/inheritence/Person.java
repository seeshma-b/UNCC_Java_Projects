/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inheritence;
import java.util.ArrayList;
/**
 *
 * @author Seesh
 */

/**
 * The Person class represents a person with a first name, last name, and ID.
 */
public class Person {
    private String firstName;
    private String lastName;
    private int id;
    
    /**
     * Constructs a Person object with the specified first name, last name, and ID.
     *
     * @param firstName the first name of the person
     * @param lastName  the last name of the person
     * @param id        the ID of the person
     */
public Person(String firstName, String lastName, int id) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
    }
    
    /**
     * Returns the first name of the person.
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Returns the last name of the person.
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Returns the ID of the person.
     * @return the ID
     */
    public int getId() {
        return id;
    }
    /**
     * Displays the details of the person
     */
    protected void display() {  //made it protected instead of private so s1.display can work. 
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("ID: " + id);
    }
    /**
     * main method that uses Person, Student, and Professor classes
     * @param other
     */
    @Override
    public boolean equals(Object other) {
            if (other == null) { 
                return false;
            }
            if (this.getClass() != other.getClass()) { 
                return false;
            }
            return this.getId() == ((Person) other).getId();
        }
} 
