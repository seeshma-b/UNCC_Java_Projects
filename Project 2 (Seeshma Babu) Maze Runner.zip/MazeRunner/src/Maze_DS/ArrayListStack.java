package Maze_DS;

import DataStructures.EmptyCollectionException;
import DataStructures.StackADT;
import java.util.ArrayList;

/**
 *
 * @author Seesh
 * @param <T> the type of elements held in the stack ArrayListStack is an
 * implementation of the StackADT interface using an ArrayList. It allows
 * elements of a generic type to be pushed onto the stack, popped from the
 * stack, peeked at the top element, checked for emptiness, and queried for its
 * size.
 */
public class ArrayListStack<T> implements StackADT<T> {

    private ArrayList<T> stack;
    private int size;

    /**
     * Constructs an empty ArrayListStack.
     */
    public ArrayListStack() { //initialize the stack and size
        stack = new ArrayList<>();
        size = 0;
    }

    /**
     * Pushes the specified element onto the top of the stack.
     *
     * @param element the element to be pushed onto the stack
     */
    @Override
    public void push(T element) {
        stack.add(element); // Adding element to the top of the stack
        size++;
    }

    /**
     * Removes and returns the top element from the stack.
     *
     * @return the top element of the stack
     * @throws EmptyCollectionException if the stack is empty
     */
    @Override
    public T pop() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Stack is empty");
        }
        T poppedElement = stack.remove(size - 1); // delete and return the top element
        size--;
        return poppedElement;
    }

    /**
     * Returns the top element of the stack without removing it.
     *
     * @return the top element of the stack
     * @throws EmptyCollectionException if the stack is empty
     */
    @Override
    public T peek() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Stack is empty");
        }
        return stack.get(size - 1); // returning the top element without removing it
    }

    /**
     * Checks if the stack is empty.
     *
     * @return true if the stack is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns the number of elements currently on the stack.
     *
     * @return the size of the stack
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Returns a string representation of the ArrayListStack, including its
     * underlying ArrayList and the current size.
     *
     * @return a string representation of the ArrayListStack
     */
    @Override
    public String toString() {
        return "ArrayListStack{" + "stack=" + stack + ", size=" + size + '}';
    }

}
