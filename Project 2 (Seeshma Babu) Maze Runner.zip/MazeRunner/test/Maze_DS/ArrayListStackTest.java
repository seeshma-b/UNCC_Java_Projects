package Maze_DS;

import DataStructures.EmptyCollectionException;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Seesh
 */
public class ArrayListStackTest {

    public ArrayListStackTest() {
    }

    /**
     * Test of push method, of class ArrayListStack.
     */
    @Test
    public void testPush() {
        System.out.println("push");
        ArrayListStack<String> instance = new ArrayListStack<>(); //replace object with string
        String element = "TestElement"; //replace with the element you want in the stack
        instance.push(element);
        //check stack is not empty after push
        assertFalse(instance.isEmpty());
        //check the size increased by 1 after push
        assertEquals(1, instance.size());
    }

    /**
     * Test of pop method, of class ArrayListStack.
     */
    @Test
    public void testPop() {
        System.out.println("pop");
        ArrayListStack<String> instance = new ArrayListStack<>();
        String element = "TestElement";
        instance.push(element);
        try {
            //start the pop
            String result = instance.pop();
            //check the popped element is equal to the one push
            assertEquals(element, result);
            // check that the stack is empty after pop
            assertTrue(instance.isEmpty());
            //check the size decreased by 1 after pop
            assertEquals(0, instance.size());
        } catch (EmptyCollectionException e) {
            fail("Exception should not be thrown when popping a non-empty stack.");
        }
    }

    /**
     * Test of peek method, of class ArrayListStack.
     */
    @Test
    public void testPeek() {
        System.out.println("peek");
        ArrayListStack<String> instance = new ArrayListStack<>();
        String element = "TestElement";
        instance.push(element);
        try {
            //start the peek 
            String result = instance.peek();
            //check the peeked element is equal to the one push
            assertEquals(element, result);
            //check the stack is not empty after peek
            assertFalse(instance.isEmpty());
            //check the size remains the same after peek
            assertEquals(1, instance.size());
        } catch (EmptyCollectionException e) {
            fail("Exception should not be thrown when peeking a non-empty stack.");
        }
    }

    /**
     * Test of isEmpty method, of class ArrayListStack.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        ArrayListStack<String> instance = new ArrayListStack<>();
        assertTrue(instance.isEmpty());
        instance.push("TestElement");
        assertFalse(instance.isEmpty());
    }

    /**
     * Test of size method, of class ArrayListStack.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        ArrayListStack<String> instance = new ArrayListStack<>();
        //check that the initial size is 0
        assertEquals(0, instance.size());
        //push an element onto the stack and check that the size is 1
        instance.push("TestElement");
        assertEquals(1, instance.size());
    }

    /**
     * Test of toString method, of class ArrayListStack.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        ArrayListStack<String> instance = new ArrayListStack<>();
        String element1 = "Element1";
        String element2 = "Element2";
        instance.push(element1);
        instance.push(element2);
        //check that the toString() method returns a string of stack
        String expectedString = "ArrayListStack{stack=[Element1, Element2], size=2}";
        assertEquals(expectedString, instance.toString());
    }

}
