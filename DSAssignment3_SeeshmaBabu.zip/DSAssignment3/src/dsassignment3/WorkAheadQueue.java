/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsassignment3;

import java.util.ArrayList;

/**
 *
 * @author Seesh
 * @param <T> The type of elements to be stored in the queue.
 */
public class WorkAheadQueue<T> implements WorkAheadQueueADT<T> {

    protected LinearNode<T> front;
    protected LinearNode<T> back;
    protected ArrayList<LinearNode<T>> frontThreeNodes;
    protected ArrayList<T> frontThreeElements;
    protected int numNodes;

    public WorkAheadQueue() {
        front = null;
        back = null;
        frontThreeNodes = new ArrayList<>();
        frontThreeElements = new ArrayList<>();
        numNodes = 0;
    }

    @Override
public T dequeue(int x) throws EmptyCollectionException, InvalidArgumentException {
    // Removes and returns the element at index x in the queue (where x < 3).
    if (isEmpty() || x < 0 || x >= 3) {
        throw new InvalidArgumentException("Invalid index or queue is empty.");
    }

    LinearNode<T> currentNode = front;

    // Traverse the list to the node at index x
    for (int i = 0; i < x; i++) {
        currentNode = currentNode.getNext();
    }

    T removedElement = currentNode.getElement();

    // If removing the front node, update front
    if (x == 0) {
        front = front.getNext();
    } else {
        // For other nodes, adjust the previous node's next pointer
        LinearNode<T> prevNode = currentNode.getPrev();
        prevNode.setNext(currentNode.getNext());

        // If removing the last node, update back
        if (x == numNodes - 1) {
            back = prevNode;
        }
    }

    // Refresh frontThree if the size is less than or equal to 3
    if (numNodes <= 3) {
        refreshFrontThree();
    }

    numNodes--;

    // Update the ArrayLists
    if (!frontThreeElements.isEmpty()) {
        frontThreeElements.remove(0);
        frontThreeNodes.remove(0);
    }

    return removedElement;
}

    @Override
    public T first(int x) throws EmptyCollectionException, InvalidArgumentException {
        // Returns (without removing) the element at index x in the queue (where x < 3).
        if (isEmpty() || x < 0 || x >= numNodes) {
            throw new InvalidArgumentException("Invalid index or queue is empty.");
        }

        // LinearNode to keep track of the node to be returned
        LinearNode<T> currentNode = front;

        // Move to the desired index using .getNext() method
        for (int i = 0; i < x; i++) {
            currentNode = currentNode.getNext();
        }

        // Return the element at the specified index
        return currentNode.getElement();
    }

    @Override
    public ArrayList<LinearNode<T>> firstThreeNodes() throws EmptyCollectionException {
        // Returns an ArrayList of the first three nodes in the queue.
        ArrayList<LinearNode<T>> result = new ArrayList<>();
        LinearNode<T> currentNode = front;

        for (int i = 0; i < 3 && currentNode != null; i++) {
            result.add(currentNode);
            currentNode = currentNode.getNext();
        }

        return result;
    }

    @Override
    public ArrayList<T> firstThreeElements() throws EmptyCollectionException {
        // Returns an ArrayList of the first three elements in the queue.
        return new ArrayList<>(frontThreeElements);
    }

    @Override
    public void enqueue(T element) {
        // Adds the specified element to the back of the queue.
        LinearNode<T> newNode = new LinearNode<>(element);

        if (isEmpty()) {
            front = newNode;
        } else {
            back.setNext(newNode);
        }

        back = newNode;
        numNodes++;

        // Update the ArrayLists if the added element is one of the first three
        if (frontThreeElements.size() < 3) {
            frontThreeElements.add(element);
            frontThreeNodes.add(newNode);
        }
    }

    @Override
    public T dequeue() throws EmptyCollectionException {
        // Dequeue without an index, removing the element at the front of the queue.
        if (isEmpty()) {
            throw new EmptyCollectionException("Queue is empty.");
        }

        T removedElement = front.getElement();
        front = front.getNext();
        numNodes--;

        // Update the ArrayLists
        if (!frontThreeElements.isEmpty()) {
            frontThreeElements.remove(0);
            frontThreeNodes.remove(0);
        }

        // Update back if the last node is removed
        if (numNodes == 0) {
            back = null;
        } else if (numNodes <= 3) {
            refreshFrontThree();
        }

        return removedElement;
    }

    private void refreshFrontThree() throws EmptyCollectionException {
    frontThreeElements = firstThreeElements();
    frontThreeNodes = firstThreeNodes();
}


    @Override
    public T first() throws EmptyCollectionException {
        // Returns (without removing) the element that is at the front of the queue.
        if (isEmpty()) {
            throw new EmptyCollectionException("Queue is empty.");
        }

        return front.getElement();
    }

    @Override
    public boolean isEmpty() {
        // Check if the queue is empty.
        return numNodes == 0;
    }

    @Override
    public int size() {
        // Return the number of elements in the queue.
        return numNodes;
    }

    @Override
    public String toString() {
        // Return a string representation of the queue.
        StringBuilder result = new StringBuilder();
        LinearNode<T> currentNode = front;

        while (currentNode != null) {
            result.append(currentNode.getElement());
            if (currentNode.getNext() != null) {
                result.append(", ");
            }
            currentNode = currentNode.getNext();
        }

        return result.toString();
    }

}
